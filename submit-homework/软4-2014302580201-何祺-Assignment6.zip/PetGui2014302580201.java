import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;

public class PetGui2014302580201 extends JFrame {
	private JFrame mainGui;
	private JFrame error;
	private JFrame success;
	private JFrame success2;
	private JFrame registerGui;
	private JFrame sellGui;
	private JFrame success5;
	private JFrame cart1;
	private JLabel user;
	private JLabel password;
	private JLabel user1;
	private JLabel password1;
	private JLabel phone;
	private JLabel email;
	private JFrame success4;
	private JTextField textuser;
	private JTextField textpassword;
	private JTextField textuser1;
	private JTextField textpassword1;
	private JTextField textphone;
	private JTextField textemail;
	private JButton login;
	private JButton register;
	private JButton confirm;
	private JButton error1;
	private JButton success1;
	private JButton success3;
	private JButton buy1;
	private JButton buy2;
	private JButton buy3;
	private JButton buy4;
	private JButton buy5;
	private JButton buy6;
	private JButton buy7;
	private JButton buy8;
	private JButton buy9;
	private JButton buy10;
	private JButton buy11;
	private JButton buy12;
	private JButton m;
	private JButton cart;
	private JButton del1;
	private JButton del2;
	private JButton del3;
	private JButton del4;
	private JButton del5;
	private JButton del6;
	private JButton del7;
	private JButton del8;
	private JButton del9;
	private JButton del10;
	private JButton del11;
	private JButton del12;
	private JButton success6;
	private JButton back;
	private ArrayList<Pet2014302580201> al=new ArrayList<Pet2014302580201>();
	private int number1=0;
	private int number2=0;
	private int number3=0;
	private int number4=0;
	private int number5=0;
	private int number6=0;
	private int number7=0;
	private int number8=0;
	private int number9=0;
	private int number10=0;
	private int number11=0;
	private int number12=0;

	

	public PetGui2014302580201() throws ClassNotFoundException, SQLException {
		login();
		Database2014302580201 db=new Database2014302580201(); 
		this.al=db.getPet();
	}

	public void login() {
		mainGui = new JFrame("���ｻ��ƽ̨");
		mainGui.setSize(500, 100);
		mainGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		mainGui.setLayout(new FlowLayout());
		user = new JLabel("�û���:");
		textuser = new JTextField(10);
		password = new JLabel("����:");
		textpassword = new JTextField(10);
		login = new JButton("��½");
		register = new JButton("ע��");
		mainGui.add(user);
		mainGui.add(textuser);
		mainGui.add(password);
		mainGui.add(textpassword);
		mainGui.add(login);
		mainGui.add(register);
		login.addActionListener(new handler());
		register.addActionListener(new handler());
		mainGui.setVisible(true);
		mainGui.setLocationRelativeTo(null);
	}

	public void register() {
		registerGui = new JFrame("ע��");
		registerGui.setSize(500, 100);
		registerGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		registerGui.setLayout(new FlowLayout());
		user1 = new JLabel("�û���:");
		password1 = new JLabel("����:");
		phone = new JLabel("�绰:");
		email = new JLabel("����:");
		textuser1 = new JTextField(10);
		textpassword1 = new JTextField(10);
		textphone = new JTextField(10);
		textemail = new JTextField(10);
		confirm = new JButton("ȷ��");
		registerGui.add(user1);
		registerGui.add(textuser1);
		registerGui.add(password1);
		registerGui.add(textpassword1);
		registerGui.add(phone);
		registerGui.add(textphone);
		registerGui.add(email);
		registerGui.add(textemail);
		registerGui.add(confirm);
		confirm.addActionListener(new handler());
		registerGui.setVisible(true);
		registerGui.setLocationRelativeTo(null);
	}
	public void pet(){
		sellGui=new JFrame("������Ϣ");
		sellGui.setSize(800,300);
		sellGui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		sellGui.setLayout(null);
		String[] a={"name","eat","drink","live","hobby"};
		String[][]b=new String[12][5];
		int i=0;
		for(Pet2014302580201 pet:al){
			String[] c={pet.getName(),pet.getEat(),pet.getDrink(),pet.getLive(),pet.getHobby()};
			b[i]=c;
			i++;
		}
		JTable table=new JTable(b,a);
		JScrollPane scrollPane=new JScrollPane(table);
		scrollPane.setBounds(0,0,700,200);
		buy1=new JButton("����");
		buy1.setBounds(700,20,80,15);
		buy2=new JButton("����");
		buy2.setBounds(700,35,80,15);
		buy3=new JButton("����");
		buy3.setBounds(700,50,80,15);
		buy4=new JButton("����");
		buy4.setBounds(700,65,80,15);
		buy5=new JButton("����");
		buy5.setBounds(700,80,80,15);
		buy6=new JButton("����");
		buy6.setBounds(700,95,80,15);
		buy7=new JButton("����");
		buy7.setBounds(700,110,80,15);
		buy8=new JButton("����");
		buy8.setBounds(700,125,80,15);
		buy9=new JButton("����");
		buy9.setBounds(700,140,80,15);
		buy10=new JButton("����");
		buy10.setBounds(700,155,80,15);
		buy11=new JButton("����");
		buy11.setBounds(700,170,80,15);
		buy12=new JButton("����");
		buy12.setBounds(700,185,80,15);
		cart=new JButton("�鿴���ﳵ");
		cart.setBounds(600,205,130,15);
		sellGui.add(scrollPane);
		sellGui.add(buy1);
		sellGui.add(buy2);
		sellGui.add(buy3);
		sellGui.add(buy4);
		sellGui.add(buy5);
		sellGui.add(buy6);
		sellGui.add(buy7);
		sellGui.add(buy8);
		sellGui.add(buy9);
		sellGui.add(buy10);
		sellGui.add(buy11);
		sellGui.add(buy12);
		sellGui.add(cart);
		buy1.addActionListener(new handler());
		buy2.addActionListener(new handler());
		buy3.addActionListener(new handler());
		buy4.addActionListener(new handler());
		buy5.addActionListener(new handler());
		buy6.addActionListener(new handler());
		buy7.addActionListener(new handler());
		buy8.addActionListener(new handler());
		buy9.addActionListener(new handler());
		buy10.addActionListener(new handler());
		buy11.addActionListener(new handler());
		buy12.addActionListener(new handler());
		cart.addActionListener(new handler());
		sellGui.setVisible(true);
		sellGui.setLocationRelativeTo(null);
	}
	public void cart(){
		cart1=new JFrame("���ﳵ");
		cart1.setSize(500, 500);
		cart1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		cart1.setLayout(null);
		int location=0;
		if(number1>0){
			JLabel c1=new JLabel("dog");
			c1.setBounds(0,location,80,20);
			JLabel c2=new JLabel(String.valueOf(number1));
			c2.setBounds(200,location,20,20);
			del1=new JButton("��1");
			del1.setBounds(300,location,80,20);
			cart1.add(c1);
			cart1.add(c2);
			cart1.add(del1);
			del1.addActionListener(new handler());
			location+=50;
		}
		if(number2>0){
			JLabel c1=new JLabel("cat");
			c1.setBounds(0,location,80,20);
			JLabel c2=new JLabel(String.valueOf(number2));
			c2.setBounds(200,location,20,20);
			del2=new JButton("��1");
			del2.setBounds(300,location,80,20);
			cart1.add(c1);
			cart1.add(c2);
			cart1.add(del2);
			del2.addActionListener(new handler());
			location+=50;
		}
		if(number3>0){
			JLabel c1=new JLabel("turtle");
			c1.setBounds(0,location,80,20);
			JLabel c2=new JLabel(String.valueOf(number3));
			c2.setBounds(200,location,20,20);
			del3=new JButton("��1");
			del3.setBounds(300,location,80,20);
			cart1.add(c1);
			cart1.add(c2);
			cart1.add(del3);
			del3.addActionListener(new handler());
			location+=50;
		}
		if(number4>0){
			JLabel c1=new JLabel("parrot");
			c1.setBounds(0,location,80,20);
			JLabel c2=new JLabel(String.valueOf(number4));
			c2.setBounds(200,location,20,20);
			del4=new JButton("��1");
			del4.setBounds(300,location,80,20);
			cart1.add(c1);
			cart1.add(c2);
			cart1.add(del4);
			del4.addActionListener(new handler());
			location+=50;
		}
		if(number5>0){
			JLabel c1=new JLabel("hamster");
			c1.setBounds(0,location,80,20);
			JLabel c2=new JLabel(String.valueOf(number5));
			c2.setBounds(200,location,20,20);
			del5=new JButton("��1");
			del5.setBounds(300,location,80,20);
			cart1.add(c1);
			cart1.add(c2);
			cart1.add(del5);
			del5.addActionListener(new handler());
			location+=50;
		}
		if(number6>0){
			JLabel c1=new JLabel("squirrel");
			c1.setBounds(0,location,80,20);
			JLabel c2=new JLabel(String.valueOf(number6));
			c2.setBounds(200,location,20,20);
			del6=new JButton("��1");
			del6.setBounds(300,location,80,20);
			cart1.add(c1);
			cart1.add(c2);
			cart1.add(del6);
			del6.addActionListener(new handler());
			location+=50;
		}
		if(number7>0){
			JLabel c1=new JLabel("rabbit");
			c1.setBounds(0,location,80,20);
			JLabel c2=new JLabel(String.valueOf(number7));
			c2.setBounds(200,location,20,20);
			del7=new JButton("��1");
			del7.setBounds(300,location,80,20);
			cart1.add(c1);
			cart1.add(c2);
			cart1.add(del7);
			del7.addActionListener(new handler());
			location+=50;
		}
		if(number8>0){
			JLabel c1=new JLabel("snake");
			c1.setBounds(0,location,80,20);
			JLabel c2=new JLabel(String.valueOf(number8));
			c2.setBounds(200,location,20,20);
			del8=new JButton("��1");
			del8.setBounds(300,location,80,20);
			cart1.add(c1);
			cart1.add(c2);
			cart1.add(del8);
			del8.addActionListener(new handler());
			location+=50;
		}
		if(number9>0){
			JLabel c1=new JLabel("lizard");
			c1.setBounds(0,location,80,20);
			JLabel c2=new JLabel(String.valueOf(number9));
			c2.setBounds(200,location,20,20);
			del9=new JButton("��1");
			del9.setBounds(300,location,80,20);
			cart1.add(c1);
			cart1.add(c2);
			cart1.add(del9);
			del9.addActionListener(new handler());
			location+=50;
		}
		if(number10>0){
			JLabel c1=new JLabel("fish");
			c1.setBounds(0,location,80,20);
			JLabel c2=new JLabel(String.valueOf(number10));
			c2.setBounds(200,location,20,20);
			del10=new JButton("��1");
			del10.setBounds(300,location,80,20);
			cart1.add(c1);
			cart1.add(c2);
			cart1.add(del10);
			del10.addActionListener(new handler());
			location+=50;
		}
		if(number11>0){
			JLabel c1=new JLabel("myna");
			c1.setBounds(0,location,80,20);
			JLabel c2=new JLabel(String.valueOf(number11));
			c2.setBounds(200,location,20,20);
			del11=new JButton("��1");
			del11.setBounds(300,location,80,20);
			cart1.add(c1);
			cart1.add(c2);
			cart1.add(del11);
			del11.addActionListener(new handler());
			location+=50;
		}
		if(number12>0){
			JLabel c1=new JLabel("canary");
			c1.setBounds(0,location,80,20);
			JLabel c2=new JLabel(String.valueOf(number12));
			c2.setBounds(200,location,20,20);
			del12=new JButton("��1");
			del12.setBounds(300,location,80,20);
			cart1.add(c1);
			cart1.add(c2);
			cart1.add(del12);
			del12.addActionListener(new handler());
			location+=50;
		}
		back=new JButton("����");
		back.setBounds(0,location,80,20);
		cart1.add(back);
		back.addActionListener(new handler());
		cart1.setVisible(true);
		cart1.setLocationRelativeTo(null);
	}
	public void success(){
		success=new JFrame();
		success.setSize(500, 100);
		success.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		success.setLayout(new FlowLayout());
		JLabel a=new JLabel("ע��ɹ�");
		success1=new JButton("ȷ��");
		success.add(a);
		success.add(success1);
		success1.addActionListener(new handler());
		success.setVisible(true);
		success.setLocationRelativeTo(null);
	}
	public void success1(){
		success2=new JFrame();
		success2.setSize(500, 100);
		success2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		success2.setLayout(new FlowLayout());
		JLabel a=new JLabel("��½�ɹ�");
		success3=new JButton("ȷ��");
		success2.add(a);
		success2.add(success3);
		success3.addActionListener(new handler());
		success2.setVisible(true);
		success2.setLocationRelativeTo(null);
	}
	public void success2(){
		success5=new JFrame();
		success5.setSize(500, 100);
		success5.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		success5.setLayout(new FlowLayout());
		JLabel a=new JLabel("�����ɹ�");
		success6=new JButton("ȷ��");
		success5.add(a);
		success5.add(success6);
		success6.addActionListener(new handler());
		success5.setVisible(true);
		success5.setLocationRelativeTo(null);
	}
	public void error(){
		error=new JFrame();
		error.setSize(500, 100);
		error.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		error.setLayout(new FlowLayout());
		JLabel a=new JLabel("�û�ע��ʧ��");
		error1=new JButton("ȷ��");
		error.add(a);
		error.add(error1);
		error1.addActionListener(new handler());
		error.setVisible(true);
		error.setLocationRelativeTo(null);
	}
	public void buy(){
		success4=new JFrame();
		success4.setSize(500, 100);
		success4.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		success4.setLayout(new FlowLayout());
		JLabel a=new JLabel("����ɹ�");
		m=new JButton("ȷ��");
		success4.add(a);
		success4.add(m);
		m.addActionListener(new handler());
		success4.setVisible(true);
		success4.setLocationRelativeTo(null);
	}

	private class handler implements ActionListener {
		public void actionPerformed(ActionEvent event) {
			if (event.getSource() == login) {
				String url = "jdbc:mysql://localhost:3306/my_schema?user=root&password=123456";
				Connection conn = null;
				Statement state=null;
				try {
					Class.forName("com.mysql.jdbc.Driver");
					conn = DriverManager.getConnection(url);
					state = conn.createStatement();
					String sql = "SELECT * FROM my_schema.2014302580201_user";
					ResultSet rs = state.executeQuery(sql);
					while (rs.next()) {
						if(rs.getString(1).equals(textuser.getText())&&rs.getString(2).equals(textpassword.getText())){
							success1();
						}
					}
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			if (event.getSource() == register) {
				register();
				mainGui.dispose();
			}
			if (event.getSource() == confirm) {
				String url = "jdbc:mysql://localhost:3306/my_schema?user=root&password=heqi0313";
				Connection conn = null;
				Statement state=null;
				try {
					Class.forName("com.mysql.jdbc.Driver");
					conn = DriverManager.getConnection(url);
					state = conn.createStatement();
					String sql = "insert into " + "2014302580201_user" + "(user,password,phone,email)" + "values('"
							+ textuser1.getText() + "','" + textpassword1.getText() + "','" + textphone.getText() + "','"
							+ textemail.getText()  + "')";
					state.executeUpdate(sql);
					state.close();
					conn.close();
					success();
				} catch (Exception e) {
					error();
				}
			}
			if(event.getSource()==error1){
				error.dispose();
			}
			if(event.getSource()==success1){
				success.dispose();
				registerGui.dispose();
				mainGui.setVisible(true);
			}
			if(event.getSource()==success3){
				success2.dispose();
				mainGui.dispose();
				pet();
			}
			if(event.getSource()==buy1){
				buy();
				number1++;
			}
			if(event.getSource()==buy2){
				buy();
				number2++;
			}
			if(event.getSource()==buy3){
				buy();
				number3++;
			}
			if(event.getSource()==buy4){
				buy();
				number4++;
			}
			if(event.getSource()==buy5){
				buy();
				number5++;
			}
			if(event.getSource()==buy6){
				buy();
				number6++;
			}
			if(event.getSource()==buy7){
				buy();
				number7++;
			}
			if(event.getSource()==buy8){
				buy();
				number8++;
			}
			if(event.getSource()==buy9){
				buy();
				number9++;
			}
			if(event.getSource()==buy10){
				buy();
				number10++;
			}
			if(event.getSource()==buy11){
				buy();
				number11++;
			}
			if(event.getSource()==buy12){
				buy();
				number12++;
			}
			if(event.getSource()==m){
				success4.dispose();
			}
			if(event.getSource()==cart){
				cart();
				sellGui.dispose();
			}
			if(event.getSource()==del1){
				success2();
				number1--;
			}
			if(event.getSource()==del2){
				success2();
				number2--;
			}
			if(event.getSource()==del3){
				success2();
				number3--;
			}
			if(event.getSource()==del4){
				success2();
				number4--;
			}
			if(event.getSource()==del5){
				success2();
				number5--;
			}
			if(event.getSource()==del6){
				success2();
				number6--;
			}
			if(event.getSource()==del7){
				success2();
				number7--;
			}
			if(event.getSource()==del8){
				success2();
				number8--;
			}
			if(event.getSource()==del9){
				success2();
				number9--;
			}
			if(event.getSource()==del10){
				success2();
				number10--;
			}
			if(event.getSource()==del11){
				success2();
				number11--;
			}
			if(event.getSource()==del12){
				success2();
				number12--;
			}
			if(event.getSource()==success6){
				success5.dispose();
				cart1.dispose();
				cart();
			}
			if(event.getSource()==back){
				sellGui.setVisible(true);
				cart1.dispose();
			}
		}
	}
}
