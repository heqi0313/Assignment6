
public class Pet2014302580201 {
private int id;
private String name;
private String eat;
private String drink;
private String live;
private String hobby;

public Pet2014302580201(int id,String name,String eat,String drink,String live,String hobby){
	this.id=id;
	this.name=name;
	this.eat=eat;
	this.drink=drink;
	this.live=live;
	this.hobby=hobby;
}
public int getId(){
	return id;
}
public String getName(){
	return name;
}
public String getEat(){
	return eat;
}
public String getDrink(){
	return drink;
}
public String getLive(){
	return live;
}
public String getHobby(){
	return hobby;
}
}
