import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class Database2014302580201 {
	public ArrayList<Pet2014302580201> getPet() throws SQLException, ClassNotFoundException {
		ArrayList<Pet2014302580201> al = new ArrayList<Pet2014302580201>();
		String url = "jdbc:mysql://localhost:3306/my_schema?user=root&password=heqi0313";
		Connection conn = null;
		Class.forName("com.mysql.jdbc.Driver");
		conn = DriverManager.getConnection(url);
		Statement state = conn.createStatement();
		String sql = "SELECT * FROM my_schema.pet";
		ResultSet rs = state.executeQuery(sql);
		while (rs.next()) {
			Pet2014302580201 tm = new Pet2014302580201(rs.getInt(1), rs.getString(2), rs.getString(3),
					rs.getString(4), rs.getString(5), rs.getString(6));
			al.add(tm);
		}
		state.close();
		conn.close();
		return al;
	}
}
