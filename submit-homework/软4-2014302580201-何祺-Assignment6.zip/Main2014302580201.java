import java.sql.SQLException;

public class Main2014302580201 {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		PetGui2014302580201 a=new PetGui2014302580201();
	}

}
