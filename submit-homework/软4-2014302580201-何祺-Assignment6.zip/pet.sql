﻿# Host: localhost  (Version: 5.5.40)
# Date: 2015-11-21 17:32:18
# Generator: MySQL-Front 5.3  (Build 4.120)

/*!40101 SET NAMES utf8 */;

#
# Structure for table "pet"
#

CREATE TABLE `pet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL DEFAULT '',
  `eat` varchar(255) NOT NULL DEFAULT '',
  `drink` varchar(255) NOT NULL DEFAULT '',
  `live` varchar(255) NOT NULL DEFAULT '',
  `hobby` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

#
# Data for table "pet"
#

INSERT INTO `pet` VALUES (1,'dog','bone','water','ground','play'),(2,'cat','fish','milk','roof','hug'),(3,'turtle','fish,shrimp','sea water','sea water','bask'),(4,'parrot','nuts,seeds','water','tree','fly'),(5,'hamster','Sunflower seed','water','corner','eat'),(6,'squirrel','pine cone','water','tree hole,underground','play'),(7,'rabbit','carrot','water','grassland,underground','eat'),(8,'snake','mouse','water','hole','bask'),(9,'lizard','bug','water','tree','bask'),(10,'fish','aquatic plant','water','water','swim'),(11,'myna','earthworm','water','tree','fly'),(12,'canary','millet','water','tree','sing');
