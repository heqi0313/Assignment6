package test;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

public class Screen extends JPanel
{
	FlowLayout flow = new FlowLayout();
	GetInformation petData;
	final long serialVersionUID = -2097214612848015645L;
	JLabel jb1 = new JLabel();
    JTextField txtUserName;
    JTextField number;
    JLabel jb2 = new JLabel();
    JPasswordField txtPassWord;
    JTextArea jt1 = new JTextArea();
    JButton regist = new JButton();
    JButton loginIn = new JButton();
    JTextArea text = new JTextArea();
    JLabel bel1;
    JLabel bel2;
	public Screen()
	{
		screen1();
	}

	public void screen1() 
	{// ��¼ע��ҳ��
		// TODO �Զ����ɵķ������
		this.removeAll();
        this.setLayout(flow);
        txtUserName = new JTextField(30);
        txtPassWord = new JPasswordField(30);
        jb1.setText("�û���");
        txtUserName.setText("");
        jb2.setText("��    ��");
        txtPassWord.setText("");
        jt1.setText("");
        regist.setText("ע��");
        regist.addActionListener(new Screen_jButton1_actionAdapter(this));
        loginIn.setText("��¼");
        loginIn.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO �Զ����ɵķ������
			screen2();	
			}
        });
       
        this.add(jb1);
        this.add(txtUserName);
        this.add(jb2);
        this.add(txtPassWord);
        this.add(jt1);
        this.add(regist);
        this.add(loginIn);
	    }
	 
	public void screen2() 
	{
		// TODO �Զ����ɵķ������
		this.removeAll();
		petData = new GetInformation();
		for (int i = 0; i<petData.pet.size(); i++)
			text.append(petData.pet.get(i)+ "\n\r");
		text.setEditable(false);
		bel1 = new JLabel("Don't you want such lovely animals?!!");
		bel2 = new JLabel("Take them, you'll have more fun in your live!");
		jb1.setText("Animals Id:");
		txtUserName = new JTextField(25);
		txtUserName.setText("");
        jb2.setText("Animals number:");
        number = new JTextField(25);
        number.setText("");
        loginIn.setText("ȷ��");
        loginIn.addActionListener(new ActionListener(){
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO �Զ����ɵķ������
				int id = Integer.parseInt(txtUserName.getText());
				String s = null;
				switch(id)
				{
				case 1: s = "dog"; break;
				case 2: s = "cat"; break;
				case 3: s = "turtle"; break;
				case 4: s = "parrot"; break;
				case 5: s = "hamster"; break;
				case 6: s = "squirrel"; break;
				case 7: s = "rabbit"; break;
				case 8: s = "snake"; break;
				case 9: s = "lizard"; break;
				case 10: s = "fish"; break;
				case 11: s = "myna"; break;
				case 12: s = "canary"; break;
				default:break;
				}
				int num = Integer.parseInt(number.getText());
				if (s != null && id != 0)
					System.out.println("Congratulations!!!!!"+"\nYou have got "+ num + " " +s);
				else
					System.out.println("I'm sorry!! You entered invalid information!");
			}
        });
        
		this.add(text);
		this.add(bel1);
		this.add(bel2);
		this.add(jb2);
		this.add(number);
		this.add(jb1);
		this.add(txtUserName);
		this.add(loginIn);
		setVisible(false);
	    setVisible(true);
	}

	class Screen_jButton1_actionAdapter implements ActionListener{
	    private Screen adaptee;
	 
	    Screen_jButton1_actionAdapter(Screen adaptee){
	        this.adaptee=adaptee;
	    }
	   
	    @Override
	    public void actionPerformed(ActionEvent e) {
	        SwingUtilities.invokeLater(new Runnable(){
	 
	                @Override
	                public void run() {
	                    try {
	                        UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	                    } catch (Exception e2) {
	                        e2.printStackTrace();
	                    }
	                    String username=adaptee.txtUserName.getText();
	                    char[] pwd=adaptee.txtPassWord.getPassword();
	                    adaptee.jt1.setText("�����û����ǣ�"+username+"�������������ǣ�"+String.valueOf(pwd));  
	                }
	        }); 
	    }
	}
}
