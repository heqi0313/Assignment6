package test;

import javax.swing.*;

public class Main2014302580207 extends JFrame 
{
	
	static Screen screen = new Screen();
	
	public  static void main(String[] args) {
        Main2014302580207 textFrame=new Main2014302580207();
        textFrame.add(screen);
        textFrame.setSize(350,460);
        textFrame.setVisible(true);
    }
}
