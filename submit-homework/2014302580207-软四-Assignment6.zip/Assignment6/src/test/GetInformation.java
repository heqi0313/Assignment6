package test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class GetInformation 
{
	final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	final String URL = "jdbc:mysql://127.0.0.1:3306/pet?user=root&password=815322";
	public ArrayList<String> pet;

	public GetInformation()
	{
		Data();
	}

	public void Data()
	{	//�������ݿ⣬��ó�����Ϣ
		try {
			pet = new ArrayList<String>();
			Class.forName(JDBC_DRIVER);
			Connection conn = DriverManager.getConnection(URL);
			Statement stmt = conn.createStatement();
			System.out.println("Connected database successfully...");
			String sql = "SELECT id, name, eat, drink, place, thing FROM pet";
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
				pet.add(rs.getString("id")+"  "+rs.getString("name")+"  "
						+rs.getString("eat")+"  "+rs.getString("drink")+"  "+rs.getString("place")+" "+rs.getString("thing"));
			}
			rs.close();
			
		} catch (ClassNotFoundException | SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		
	}
}
